# CIDI89 - Sintetizador Analógico

Sintetizador VST3 (instrumento / VSTi) para Windows, feito com JUCE.

## Funcionalidades
- 2 osciladores (Sine / Saw / Square / Triangle, anti-aliasing PolyBLEP), oitava, semitom, fine, nível
- Sub-oscilador e ruído
- **Hypersaw Unison** (até 7 vozes, detune, blend, largura estéreo)
- Filtro LP/BP/HP com ressonância, envelope e drive
- LFO (pitch e filtro), ADSR de amplitude e de filtro (faders)
- Chorus e Reverb, volume master
- 16 vozes de polifonia, pitch bend, teclado no ecrã, presets originais

## Compilar
Requisitos: Visual Studio 2022 (C++), CMake 3.22+, Git.

    cmake -B build -G "Visual Studio 17 2022" -A x64
    cmake --build build --config Release

O `.vst3` fica em `build/CIDI89_artefacts/Release/VST3/`. Copie para `C:\Program Files\Common Files\VST3`.

O workflow `.github/workflows/build.yml` compila automaticamente no GitHub Actions.

## Licença
JUCE é AGPLv3 / comercial. Este projeto, ao usar JUCE sob AGPLv3, deve ser publicado com código-fonte sob AGPLv3 (ou compre licença JUCE para código fechado).
Todos os sons/presets deste repositório são originais.

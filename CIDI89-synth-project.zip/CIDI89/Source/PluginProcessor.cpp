#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "SynthEngine.h"
#include "Presets.h"

using APVTS = juce::AudioProcessorValueTreeState;
using Range = juce::NormalisableRange<float>;

APVTS::ParameterLayout CidiProcessor::createLayout() {
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;
    auto F = [&](const char* id, const char* name, Range r, float def) {
        p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{ id, 1 }, name, r, def)); };
    auto I = [&](const char* id, const char* name, int a, int b, int def) {
        p.push_back(std::make_unique<juce::AudioParameterInt>(juce::ParameterID{ id, 1 }, name, a, b, def)); };
    auto C = [&](const char* id, const char* name, juce::StringArray c, int def) {
        p.push_back(std::make_unique<juce::AudioParameterChoice>(juce::ParameterID{ id, 1 }, name, c, def)); };

    const juce::StringArray waves { "Sine", "Saw", "Square", "Triangle" };
    C("osc1_wave", "Osc1 Wave", waves, 1); I("osc1_oct", "Osc1 Octave", -3, 3, 0);
    I("osc1_semi", "Osc1 Semi", -12, 12, 0); F("osc1_fine", "Osc1 Fine", Range(-100.f, 100.f, 0.1f), 0.f);
    F("osc1_lvl", "Osc1 Level", Range(0.f, 1.f, 0.001f), 0.7f);
    C("osc2_wave", "Osc2 Wave", waves, 1); I("osc2_oct", "Osc2 Octave", -3, 3, 0);
    I("osc2_semi", "Osc2 Semi", -12, 12, 0); F("osc2_fine", "Osc2 Fine", Range(-100.f, 100.f, 0.1f), 5.f);
    F("osc2_lvl", "Osc2 Level", Range(0.f, 1.f, 0.001f), 0.4f);
    F("sub_lvl", "Sub", Range(0.f, 1.f, 0.001f), 0.f);
    F("noise_lvl", "Noise", Range(0.f, 1.f, 0.001f), 0.f);

    I("uni_voices", "Unison Voices", 1, 7, 1);
    F("uni_detune", "Unison Detune", Range(0.f, 100.f, 0.1f), 20.f);
    F("uni_blend", "Unison Blend", Range(0.f, 1.f, 0.001f), 0.8f);
    F("uni_width", "Unison Width", Range(0.f, 1.f, 0.001f), 0.8f);

    C("flt_type", "Filter Type", { "Low Pass", "Band Pass", "High Pass" }, 0);
    F("flt_cut", "Cutoff", Range(20.f, 20000.f, 0.01f, 0.3f), 8000.f);
    F("flt_res", "Resonance", Range(0.f, 1.f, 0.001f), 0.1f);
    F("flt_env", "Filter Env Amt", Range(-1.f, 1.f, 0.001f), 0.3f);
    F("drive", "Drive", Range(0.f, 1.f, 0.001f), 0.f);

    Range t(0.001f, 5.f, 0.001f, 0.4f);
    F("amp_a", "Amp A", t, 0.01f); F("amp_d", "Amp D", t, 0.3f);
    F("amp_s", "Amp S", Range(0.f, 1.f, 0.001f), 0.8f); F("amp_r", "Amp R", t, 0.3f);
    F("flt_a", "Flt A", t, 0.01f); F("flt_d", "Flt D", t, 0.4f);
    F("flt_s", "Flt S", Range(0.f, 1.f, 0.001f), 0.3f); F("flt_r", "Flt R", t, 0.3f);

    F("lfo_rate", "LFO Rate", Range(0.05f, 20.f, 0.01f, 0.4f), 2.f);
    F("lfo_pitch", "LFO Pitch", Range(0.f, 2.f, 0.001f), 0.f);
    F("lfo_cut", "LFO Filter", Range(0.f, 1.f, 0.001f), 0.f);

    F("chorus_mix", "Chorus", Range(0.f, 1.f, 0.001f), 0.f);
    F("rev_size", "Reverb Size", Range(0.f, 1.f, 0.001f), 0.5f);
    F("rev_mix", "Reverb Mix", Range(0.f, 1.f, 0.001f), 0.f);
    F("master", "Master", Range(0.f, 1.f, 0.001f), 0.7f);
    return { p.begin(), p.end() };
}

CidiProcessor::CidiProcessor()
    : AudioProcessor(BusesProperties().withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "STATE", createLayout()) {
    synth.addSound(new CidiSound());
    for (int i = 0; i < 16; ++i) synth.addVoice(new CidiVoice(apvts));
}

void CidiProcessor::prepareToPlay(double sr, int bs) {
    synth.setCurrentPlaybackSampleRate(sr);
    chorus.prepare({ sr, (juce::uint32) bs, 2u });
    chorus.reset();
    reverb.setSampleRate(sr);
    reverb.reset();
    keyboardState.reset();
}

void CidiProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi) {
    juce::ScopedNoDenormals noDenormals;
    const int n = buffer.getNumSamples();
    buffer.clear();
    keyboardState.processNextMidiBuffer(midi, 0, n, true);
    synth.renderNextBlock(buffer, midi, 0, n);

    auto get = [this](const char* id) { return apvts.getRawParameterValue(id)->load(); };

    chorus.setRate(0.8f); chorus.setDepth(0.35f); chorus.setCentreDelay(8.f);
    chorus.setFeedback(0.1f); chorus.setMix(get("chorus_mix"));
    juce::dsp::AudioBlock<float> blk(buffer);
    juce::dsp::ProcessContextReplacing<float> ctx(blk);
    chorus.process(ctx);

    juce::Reverb::Parameters rp;
    const float mix = get("rev_mix");
    rp.roomSize = get("rev_size"); rp.damping = 0.5f; rp.width = 1.f;
    rp.wetLevel = mix; rp.dryLevel = 1.f - 0.5f * mix; rp.freezeMode = 0.f;
    reverb.setParameters(rp);
    if (buffer.getNumChannels() >= 2)
        reverb.processStereo(buffer.getWritePointer(0), buffer.getWritePointer(1), n);

    buffer.applyGain(get("master"));
}

juce::AudioProcessorEditor* CidiProcessor::createEditor() { return new CidiEditor(*this); }

int CidiProcessor::getNumPrograms() { return (int) getCidiPresets().size(); }
const juce::String CidiProcessor::getProgramName(int i) {
    auto& pr = getCidiPresets();
    return (i >= 0 && i < (int) pr.size()) ? pr[(size_t) i].name : juce::String();
}
void CidiProcessor::setCurrentProgram(int idx) {
    auto& pr = getCidiPresets();
    if (idx < 0 || idx >= (int) pr.size()) return;
    currentProgram = idx;
    for (auto* prm : getParameters())
        if (auto* r = dynamic_cast<juce::RangedAudioParameter*>(prm))
            r->setValueNotifyingHost(r->getDefaultValue());
    for (auto& kv : pr[(size_t) idx].values)
        if (auto* r = apvts.getParameter(kv.first))
            r->setValueNotifyingHost(r->convertTo0to1(kv.second));
}

void CidiProcessor::getStateInformation(juce::MemoryBlock& dest) {
    if (auto xml = apvts.copyState().createXml()) copyXmlToBinary(*xml, dest);
}
void CidiProcessor::setStateInformation(const void* data, int size) {
    if (auto xml = getXmlFromBinary(data, size))
        if (xml->hasTagName(apvts.state.getType())) apvts.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new CidiProcessor(); }

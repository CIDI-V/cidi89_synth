#pragma once
#include <vector>
#include <utility>

// Presets originais do CIDI89 (valores reais dos parametros).
struct CidiPreset { const char* name; std::vector<std::pair<const char*, float>> values; };

inline const std::vector<CidiPreset>& getCidiPresets() {
    static const std::vector<CidiPreset> presets = {
        { "Init", {} },
        { "Hypersaw Lead", { {"osc1_wave",1},{"osc2_wave",1},{"osc2_fine",7},{"uni_voices",7},{"uni_detune",35},
            {"uni_blend",0.8f},{"uni_width",0.9f},{"flt_cut",6000},{"flt_res",0.15f},{"sub_lvl",0.3f},
            {"amp_a",0.005f},{"amp_d",0.3f},{"amp_s",0.8f},{"amp_r",0.3f},{"chorus_mix",0.2f},{"rev_size",0.6f},{"rev_mix",0.2f} } },
        { "Wall Of Saw Chord", { {"osc1_wave",1},{"osc2_wave",1},{"osc2_fine",-9},{"uni_voices",7},{"uni_detune",55},
            {"uni_blend",1.f},{"uni_width",1.f},{"flt_cut",3500},{"amp_a",0.02f},{"amp_d",0.5f},{"amp_s",0.7f},
            {"amp_r",0.6f},{"chorus_mix",0.3f},{"rev_size",0.8f},{"rev_mix",0.3f} } },
        { "Dark Pad", { {"osc1_wave",1},{"osc2_wave",3},{"osc2_oct",-1},{"uni_voices",5},{"uni_detune",20},
            {"flt_cut",900},{"flt_res",0.2f},{"flt_env",0.3f},{"flt_a",1.5f},{"flt_d",1.f},{"flt_s",0.6f},
            {"amp_a",1.2f},{"amp_s",0.9f},{"amp_r",2.5f},{"lfo_rate",0.3f},{"lfo_cut",0.3f},
            {"chorus_mix",0.4f},{"rev_size",0.9f},{"rev_mix",0.45f} } },
        { "Sub Bass", { {"osc1_wave",2},{"osc1_oct",-1},{"osc2_lvl",0},{"sub_lvl",0.9f},{"flt_cut",500},{"flt_env",0.4f},
            {"flt_d",0.2f},{"flt_s",0},{"amp_a",0.003f},{"amp_s",0.9f},{"amp_r",0.1f},{"drive",0.2f} } },
        { "Pluck", { {"osc1_wave",1},{"osc2_wave",2},{"uni_voices",3},{"uni_detune",10},{"flt_cut",1200},{"flt_env",0.8f},
            {"flt_a",0.001f},{"flt_d",0.25f},{"flt_s",0},{"flt_r",0.2f},{"amp_d",0.3f},{"amp_s",0},{"amp_r",0.2f},
            {"rev_mix",0.15f} } },
        { "Retro Brass", { {"osc1_wave",1},{"osc2_wave",1},{"osc2_fine",6},{"uni_voices",3},{"uni_detune",12},
            {"flt_cut",1500},{"flt_env",0.6f},{"flt_a",0.08f},{"flt_d",0.4f},{"flt_s",0.5f},{"amp_a",0.04f},
            {"amp_s",0.8f},{"lfo_rate",5},{"lfo_pitch",0.05f},{"chorus_mix",0.25f} } },
    };
    return presets;
}

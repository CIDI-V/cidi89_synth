#pragma once
#include "PluginProcessor.h"

namespace cidi {

class LnF : public juce::LookAndFeel_V4 {
public:
    LnF() {
        using namespace juce;
        setColour(Slider::textBoxTextColourId, Colour(0xffb8d4ff));
        setColour(Slider::textBoxOutlineColourId, Colours::transparentBlack);
        setColour(Label::textColourId, Colour(0xffc9d8f0));
        setColour(ComboBox::backgroundColourId, Colour(0xff0a1226));
        setColour(ComboBox::textColourId, Colour(0xffd6e6ff));
        setColour(ComboBox::outlineColourId, Colour(0xff3a6ab8));
        setColour(ComboBox::arrowColourId, Colour(0xff4aa8ff));
        setColour(PopupMenu::backgroundColourId, Colour(0xff0a1226));
        setColour(PopupMenu::textColourId, Colour(0xffd6e6ff));
        setColour(PopupMenu::highlightedBackgroundColourId, Colour(0xff2b5cb0));
        setColour(TextButton::buttonColourId, Colour(0xff1b2f55));
        setColour(TextButton::textColourOffId, Colour(0xffd6e6ff));
    }

    void drawRotarySlider(juce::Graphics& g, int x, int y, int w, int h, float pos,
                          float a0, float a1, juce::Slider&) override {
        using namespace juce;
        auto b = Rectangle<float>((float) x, (float) y, (float) w, (float) h).reduced(4.f);
        float r = jmin(b.getWidth(), b.getHeight()) / 2.f; auto c = b.getCentre();
        float ang = a0 + pos * (a1 - a0);

        Path track; track.addCentredArc(c.x, c.y, r, r, 0.f, a0, a1, true);
        g.setColour(Colour(0xff0a0f1c)); g.strokePath(track, PathStrokeType(3.5f));
        Path val; val.addCentredArc(c.x, c.y, r, r, 0.f, a0, ang, true);
        g.setColour(Colour(0xff4aa8ff)); g.strokePath(val, PathStrokeType(3.5f));

        float kr = r * 0.72f;
        g.setGradientFill(ColourGradient(Colour(0xff7d8aa6), c.x, c.y - kr, Colour(0xff10141f), c.x, c.y + kr, false));
        g.fillEllipse(c.x - kr, c.y - kr, kr * 2.f, kr * 2.f);
        g.setColour(Colour(0xff222a3d)); g.drawEllipse(c.x - kr, c.y - kr, kr * 2.f, kr * 2.f, 1.f);

        Path p; p.addRoundedRectangle(-1.5f, -kr, 3.f, kr * 0.5f, 1.f);
        g.setColour(Colours::white);
        g.fillPath(p, AffineTransform::rotation(ang).translated(c.x, c.y));
    }

    void drawLinearSlider(juce::Graphics& g, int x, int y, int w, int h, float pos, float, float,
                          juce::Slider::SliderStyle, juce::Slider&) override {
        using namespace juce;
        float cx = x + w * 0.5f;
        g.setColour(Colour(0xff050912)); g.fillRoundedRectangle(cx - 2.5f, (float) y, 5.f, (float) h, 2.f);
        g.setColour(Colour(0xff4aa8ff)); g.fillRoundedRectangle(cx - 2.5f, pos, 5.f, y + h - pos, 2.f);
        Rectangle<float> t(cx - 12.f, pos - 6.f, 24.f, 12.f);
        g.setGradientFill(ColourGradient(Colour(0xffe6ecf7), 0, t.getY(), Colour(0xff6b778f), 0, t.getBottom(), false));
        g.fillRoundedRectangle(t, 2.f);
        g.setColour(Colour(0xff1b2f55)); g.fillRect(t.getX() + 2.f, t.getCentreY() - 0.75f, t.getWidth() - 4.f, 1.5f);
    }
};

struct KnobCtl : public juce::Component {
    juce::Slider slider;
    juce::Label label;
    juce::AudioProcessorValueTreeState::SliderAttachment att;

    KnobCtl(juce::AudioProcessorValueTreeState& s, const juce::String& id, const juce::String& name, bool fader)
        : att(s, id, slider) {
        slider.setSliderStyle(fader ? juce::Slider::LinearVertical : juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 64, 14);
        label.setText(name, juce::dontSendNotification);
        label.setJustificationType(juce::Justification::centred);
        label.setFont(juce::Font(juce::FontOptions(12.f)));
        addAndMakeVisible(slider); addAndMakeVisible(label);
    }
    void resized() override {
        auto r = getLocalBounds();
        label.setBounds(r.removeFromTop(14));
        slider.setBounds(r);
    }
};

} // namespace cidi

class CidiEditor : public juce::AudioProcessorEditor {
public:
    explicit CidiEditor(CidiProcessor& p)
        : AudioProcessorEditor(&p), proc(p),
          keyboard(p.keyboardState, juce::MidiKeyboardComponent::horizontalKeyboard) {
        setLookAndFeel(&lnf);

        // Linha 0
        addSection("OSC 1", 0, 4.f, "osc1_wave", { {"osc1_oct","Oct"},{"osc1_semi","Semi"},{"osc1_fine","Fine"},{"osc1_lvl","Level"} });
        addSection("OSC 2", 0, 4.f, "osc2_wave", { {"osc2_oct","Oct"},{"osc2_semi","Semi"},{"osc2_fine","Fine"},{"osc2_lvl","Level"} });
        addSection("SUB / NOISE", 0, 2.2f, "", { {"sub_lvl","Sub"},{"noise_lvl","Noise"} });
        // Linha 1
        addSection("HYPERSAW UNISON", 1, 4.f, "", { {"uni_voices","Voices"},{"uni_detune","Detune"},{"uni_blend","Blend"},{"uni_width","Width"} });
        addSection("FILTER", 1, 4.f, "flt_type", { {"flt_cut","Cutoff"},{"flt_res","Reso"},{"flt_env","Env"},{"drive","Drive"} });
        addSection("LFO", 1, 3.f, "", { {"lfo_rate","Rate"},{"lfo_pitch","Pitch"},{"lfo_cut","Filter"} });
        // Linha 2
        addSection("AMP ENV", 2, 3.5f, "", { {"amp_a","A"},{"amp_d","D"},{"amp_s","S"},{"amp_r","R"} }, true);
        addSection("FILTER ENV", 2, 3.5f, "", { {"flt_a","A"},{"flt_d","D"},{"flt_s","S"},{"flt_r","R"} }, true);
        addSection("FX / MASTER", 2, 4.f, "", { {"chorus_mix","Chorus"},{"rev_size","Size"},{"rev_mix","Reverb"},{"master","Master"} });

        for (int i = 0; i < proc.getNumPrograms(); ++i) presetBox.addItem(proc.getProgramName(i), i + 1);
        presetBox.setSelectedItemIndex(proc.getCurrentProgram(), juce::dontSendNotification);
        presetBox.onChange = [this] { proc.setCurrentProgram(presetBox.getSelectedItemIndex()); };
        prevBtn.setButtonText("<"); nextBtn.setButtonText(">");
        prevBtn.onClick = [this] { stepPreset(-1); };
        nextBtn.onClick = [this] { stepPreset(1); };
        addAndMakeVisible(presetBox); addAndMakeVisible(prevBtn); addAndMakeVisible(nextBtn);

        keyboard.setAvailableRange(36, 96);
        keyboard.setLowestVisibleKey(36);
        keyboard.setKeyWidth(27.f);
        keyboard.setColour(juce::MidiKeyboardComponent::keyDownOverlayColourId, juce::Colour(0xaa4aa8ff));
        keyboard.setColour(juce::MidiKeyboardComponent::mouseOverKeyOverlayColourId, juce::Colour(0x554aa8ff));
        addAndMakeVisible(keyboard);

        setSize(1000, 660);
    }
    ~CidiEditor() override { setLookAndFeel(nullptr); }

    void paint(juce::Graphics& g) override {
        using namespace juce;
        g.setGradientFill(ColourGradient(Colour(0xff17254a), 0, 0, Colour(0xff060a16), 0, (float) getHeight(), false));
        g.fillAll();
        g.setColour(Colours::white);
        g.setFont(Font(FontOptions(30.f, Font::bold)));
        g.drawText("CIDI89", 20, 8, 200, 36, Justification::centredLeft);
        g.setColour(Colour(0xff7fb4ff));
        g.setFont(Font(FontOptions(13.f)));
        g.drawText("SINTETIZADOR ANALOGICO", 20, 38, 260, 16, Justification::centredLeft);

        for (auto& s : sections) {
            auto b = s->bounds.toFloat();
            g.setColour(Colour(0xff0c1a36)); g.fillRoundedRectangle(b, 6.f);
            g.setColour(Colour(0xff2b4f8f)); g.drawRoundedRectangle(b, 6.f, 1.2f);
            auto t = b.withHeight(20.f).reduced(1.f);
            g.setGradientFill(ColourGradient(Colour(0xff93a9cc), 0, t.getY(), Colour(0xff34466a), 0, t.getBottom(), false));
            g.fillRoundedRectangle(t, 5.f);
            g.setColour(Colours::white); g.setFont(Font(FontOptions(13.f, Font::bold)));
            g.drawText(s->title, t, Justification::centred);
        }
    }

    void resized() override {
        auto area = getLocalBounds().reduced(10);
        auto header = area.removeFromTop(56);
        prevBtn.setBounds(header.getRight() - 330, 16, 30, 26);
        presetBox.setBounds(header.getRight() - 296, 16, 260, 26);
        nextBtn.setBounds(header.getRight() - 32 + 10, 16, 30, 26);
        keyboard.setBounds(area.removeFromBottom(84));
        area.removeFromBottom(6);

        const int rowH = area.getHeight() / 3;
        for (int r = 0; r < 3; ++r) {
            auto rowArea = area.removeFromTop(rowH).reduced(0, 3);
            float total = 0.f; for (auto& s : sections) if (s->row == r) total += s->weight;
            const int fullW = rowArea.getWidth();
            for (auto& s : sections) {
                if (s->row != r) continue;
                s->bounds = rowArea.removeFromLeft((int)(fullW * s->weight / total)).reduced(3, 0);
                auto in = s->bounds.reduced(8, 4); in.removeFromTop(22);
                if (s->combo) { s->combo->setBounds(in.removeFromTop(24).reduced(10, 0)); in.removeFromTop(4); }
                int n = juce::jmax(1, (int) s->knobs.size());
                int cw = juce::jmin(76, in.getWidth() / n);
                int x = in.getX() + (in.getWidth() - cw * n) / 2;
                for (auto& k : s->knobs) { k->setBounds(x, in.getY(), cw, in.getHeight()); x += cw; }
            }
        }
    }

private:
    using ComboAtt = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    struct Section {
        juce::String title; int row = 0; float weight = 1.f; juce::Rectangle<int> bounds;
        std::unique_ptr<juce::ComboBox> combo; std::unique_ptr<ComboAtt> comboAtt;
        std::vector<std::unique_ptr<cidi::KnobCtl>> knobs;
    };

    void addSection(const juce::String& title, int row, float weight, const juce::String& comboId,
                    std::vector<std::pair<juce::String, juce::String>> knobs, bool fader = false) {
        auto s = std::make_unique<Section>();
        s->title = title; s->row = row; s->weight = weight;
        if (comboId.isNotEmpty()) {
            s->combo = std::make_unique<juce::ComboBox>();
            if (auto* cp = dynamic_cast<juce::AudioParameterChoice*>(proc.apvts.getParameter(comboId)))
                s->combo->addItemList(cp->choices, 1);
            s->comboAtt = std::make_unique<ComboAtt>(proc.apvts, comboId, *s->combo);
            addAndMakeVisible(*s->combo);
        }
        for (auto& k : knobs) {
            auto kc = std::make_unique<cidi::KnobCtl>(proc.apvts, k.first, k.second, fader);
            addAndMakeVisible(*kc);
            s->knobs.push_back(std::move(kc));
        }
        sections.push_back(std::move(s));
    }

    void stepPreset(int d) {
        int n = proc.getNumPrograms();
        presetBox.setSelectedItemIndex((presetBox.getSelectedItemIndex() + d + n) % n, juce::sendNotification);
    }

    cidi::LnF lnf;
    CidiProcessor& proc;
    std::vector<std::unique_ptr<Section>> sections;
    juce::ComboBox presetBox;
    juce::TextButton prevBtn, nextBtn;
    juce::MidiKeyboardComponent keyboard;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(CidiEditor)
};

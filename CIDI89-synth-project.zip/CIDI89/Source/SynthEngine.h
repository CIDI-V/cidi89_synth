#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_dsp/juce_dsp.h>

struct CidiSound : public juce::SynthesiserSound {
    bool appliesToNote(int) override { return true; }
    bool appliesToChannel(int) override { return true; }
};

class CidiVoice : public juce::SynthesiserVoice {
public:
    static constexpr int maxUni = 7;

    explicit CidiVoice(juce::AudioProcessorValueTreeState& s) : apvts(s) {}

    bool canPlaySound(juce::SynthesiserSound* s) override { return dynamic_cast<CidiSound*>(s) != nullptr; }

    void setCurrentPlaybackSampleRate(double sr) override {
        juce::SynthesiserVoice::setCurrentPlaybackSampleRate(sr);
        if (sr > 0) {
            ampEnv.setSampleRate(sr);
            fltEnv.setSampleRate(sr);
            filt.prepare({ sr, 512u, 2u });
        }
    }

    void startNote(int midi, float vel, juce::SynthesiserSound*, int pitchWheel) override {
        baseFreq = (float) juce::MidiMessage::getMidiNoteInHertz(midi);
        velocity = vel;
        pitchWheelMoved(pitchWheel);
        for (auto& o : phase) for (auto& p : o) p = rnd.nextFloat();
        subPhase = 0.f; lfoPhase = 0.f;
        filt.reset();
        ampEnv.noteOn(); fltEnv.noteOn();
    }

    void stopNote(float, bool allowTailOff) override {
        if (allowTailOff) { ampEnv.noteOff(); fltEnv.noteOff(); }
        else { ampEnv.reset(); fltEnv.reset(); clearCurrentNote(); }
    }

    void pitchWheelMoved(int v) override { bend = std::pow(2.f, ((v - 8192) / 8192.f) * 2.f / 12.f); }
    void controllerMoved(int, int) override {}

    void renderNextBlock(juce::AudioBuffer<float>& out, int start, int num) override {
        if (!isVoiceActive() || out.getNumChannels() < 2) return;
        auto P = [this](const char* id) { return apvts.getRawParameterValue(id)->load(); };
        const double sr = getSampleRate();

        const char* wId[2] = { "osc1_wave", "osc2_wave" };
        const char* oId[2] = { "osc1_oct", "osc2_oct" };
        const char* sId[2] = { "osc1_semi", "osc2_semi" };
        const char* fId[2] = { "osc1_fine", "osc2_fine" };
        const char* lId[2] = { "osc1_lvl", "osc2_lvl" };

        int wave[2]; float lvl[2], base[2];
        for (int o = 0; o < 2; ++o) {
            wave[o] = (int) P(wId[o]); lvl[o] = P(lId[o]);
            base[o] = std::pow(2.f, P(oId[o]) + (P(sId[o]) + P(fId[o]) / 100.f) / 12.f);
        }
        const int n = juce::jlimit(1, maxUni, (int) P("uni_voices"));
        const float det = P("uni_detune"), blend = P("uni_blend"), width = P("uni_width");
        float ratio[maxUni], gain[maxUni], pl[maxUni], pr[maxUni], norm = 0.f;
        for (int k = 0; k < n; ++k) {
            float off = n > 1 ? ((float) k / (float)(n - 1)) * 2.f - 1.f : 0.f;
            ratio[k] = std::pow(2.f, off * det / 1200.f);
            gain[k] = std::abs(off) < 1e-4f ? 1.f : blend;
            norm += gain[k] * gain[k];
            float ang = (off * width * 0.5f + 0.5f) * juce::MathConstants<float>::halfPi;
            pl[k] = std::cos(ang); pr[k] = std::sin(ang);
        }
        norm = 1.f / std::sqrt(juce::jmax(norm, 0.0001f));

        const float sub = P("sub_lvl"), noise = P("noise_lvl");
        const int ft = (int) P("flt_type");
        filt.setType(ft == 0 ? juce::dsp::StateVariableTPTFilterType::lowpass
                   : ft == 1 ? juce::dsp::StateVariableTPTFilterType::bandpass
                             : juce::dsp::StateVariableTPTFilterType::highpass);
        const float res = P("flt_res");
        filt.setResonance(0.707f + res * res * 12.f);
        const float cut = P("flt_cut"), fenv = P("flt_env"), drive = P("drive");
        const float lfoRate = P("lfo_rate"), lfoPitch = P("lfo_pitch"), lfoCut = P("lfo_cut");
        ampEnv.setParameters({ P("amp_a"), P("amp_d"), P("amp_s"), P("amp_r") });
        fltEnv.setParameters({ P("flt_a"), P("flt_d"), P("flt_s"), P("flt_r") });
        const float maxCut = (float) juce::jmin(20000.0, sr * 0.45);

        float* L = out.getWritePointer(0, start);
        float* R = out.getWritePointer(1, start);
        const float twoPi = juce::MathConstants<float>::twoPi;

        for (int i = 0; i < num; ++i) {
            float lfo = std::sin(lfoPhase * twoPi);
            lfoPhase += (float)(lfoRate / sr); if (lfoPhase >= 1.f) lfoPhase -= 1.f;
            float f = baseFreq * bend * std::pow(2.f, lfoPitch * lfo / 12.f);

            float sl = 0.f, sr_ = 0.f;
            for (int o = 0; o < 2; ++o) {
                if (lvl[o] <= 0.0001f) continue;
                for (int k = 0; k < n; ++k) {
                    float dt = (float)(f * base[o] * ratio[k] / sr);
                    phase[o][k] += dt; if (phase[o][k] >= 1.f) phase[o][k] -= 1.f;
                    float s = oscillator(wave[o], phase[o][k], dt) * gain[k] * norm * lvl[o];
                    sl += s * pl[k]; sr_ += s * pr[k];
                }
            }
            if (sub > 0.0001f) {
                subPhase += (float)(f * base[0] * 0.5f / sr); if (subPhase >= 1.f) subPhase -= 1.f;
                float s = std::sin(subPhase * twoPi) * sub * 0.7f; sl += s; sr_ += s;
            }
            if (noise > 0.0001f) { sl += (rnd.nextFloat() * 2.f - 1.f) * noise * 0.4f; sr_ += (rnd.nextFloat() * 2.f - 1.f) * noise * 0.4f; }

            float fe = fltEnv.getNextSample();
            float ae = ampEnv.getNextSample();
            float c = cut * std::pow(2.f, fenv * fe * 5.f + lfoCut * lfo * 2.f);
            filt.setCutoffFrequency(juce::jlimit(20.f, maxCut, c));
            sl = filt.processSample(0, sl); sr_ = filt.processSample(1, sr_);

            if (drive > 0.001f) {
                float g = 1.f + drive * 10.f, d = std::tanh(g);
                sl = std::tanh(sl * g) / d; sr_ = std::tanh(sr_ * g) / d;
            }
            float a = ae * velocity * 0.5f;
            L[i] += sl * a; R[i] += sr_ * a;

            if (!ampEnv.isActive()) { clearCurrentNote(); break; }
        }
    }

private:
    static float polyBlep(float t, float dt) {
        if (t < dt) { t /= dt; return t + t - t * t - 1.f; }
        if (t > 1.f - dt) { t = (t - 1.f) / dt; return t * t + t + t + 1.f; }
        return 0.f;
    }
    static float oscillator(int w, float ph, float dt) {
        switch (w) {
            case 0: return std::sin(juce::MathConstants<float>::twoPi * ph);
            case 1: return 2.f * ph - 1.f - polyBlep(ph, dt);
            case 2: { float v = ph < 0.5f ? 1.f : -1.f; v += polyBlep(ph, dt);
                      float p2 = ph + 0.5f; if (p2 >= 1.f) p2 -= 1.f; v -= polyBlep(p2, dt); return v; }
            default: return 1.f - 4.f * std::abs(ph - 0.5f);
        }
    }

    juce::AudioProcessorValueTreeState& apvts;
    juce::ADSR ampEnv, fltEnv;
    juce::dsp::StateVariableTPTFilter<float> filt;
    juce::Random rnd;
    float phase[2][maxUni] {};
    float baseFreq = 440.f, velocity = 1.f, bend = 1.f, subPhase = 0.f, lfoPhase = 0.f;
};
